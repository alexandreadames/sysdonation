<?php

namespace App\Models\Utils;


Class Globals {

    public const SECRET_KEY = "secret@sysdonation";

}

?>